## Donate Page

This is a simple app so people can enter an amount and make a single charge with Stripe. 

![Example](https://raw.githubusercontent.com/laravelnews/donate/master/example-image.png)

