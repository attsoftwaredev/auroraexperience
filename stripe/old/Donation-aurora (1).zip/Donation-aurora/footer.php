
<footer>
	<div class="container">
		<p>Questions? Call <a href="tel:000-8***-0**-1234">000-8***-0**-1234</a></p>
		<div class="row">
		<div class="col-md-3 col-sm-12">
			<ul>
				<li><a href="/AuroraExperiences/faq.php">FAQ</a></li>
				<li>Investor Relations</li>
				<li><a href="/AuroraExperiences/privacy-policy.php">Privacy</a></li>
			</ul>	
		</div>	
		<div class="col-md-3 col-sm-12">
			<ul>
				<li>Help Center</li>
				<li>Jobs</li>
				<li>Cookies Perferences</li>
				<li>Legal Notices</li>
			</ul>	
		</div>	
		<div class="col-md-3 col-sm-12">
			<ul>
				<li>Account</li>
				<li>Ways to Watch</li>
				<li>Corporate Information</li>
			</ul>
		</div>	
		<div class="col-md-3 col-sm-12">
			<ul>
				<li>Media Center</li>
				<li>Term of Use</li>
				<li><a href="/AuroraExperiences/contact-us.php">Contact Us</a></li>
			</ul>
		</div>	
	</div>
	</div>	
</footer>	
</body>
</html>